package edu.unicesumar.comportamental.observer;

import java.util.ArrayList;
import java.util.List;

// Implementação concreta do Subject
public class DepartamentoUnicesumar implements Subject {
    private List<Observador> observadores = new ArrayList<>();

    public void registrarObservador(Observador o) {
        observadores.add(o);
    }

    public void removerObservador(Observador o) {
        observadores.remove(o);
    }

    public void notificarObservadores(String mensagem) {
        for (Observador observador : observadores) {
            observador.atualizar(mensagem);
        }
    }

    // Exemplo de método para atualizar políticas internas
    public void atualizarPoliticasInternas(String novasPoliticas) {
        notificarObservadores("Novas políticas internas: " + novasPoliticas);
    }
}
