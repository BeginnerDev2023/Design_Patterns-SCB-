package edu.unicesumar.criacional.factory_method;

public interface Funcionario {
    void mostrarInfo();
}
