package edu.unicesumar.estrutural.decorator;

public class Main {
    public static void main(String[] args) {
        Funcionario funcionario = new FuncionarioBase();
        Funcionario funcionarioComPrivilegios = new FuncionarioAdministrativo(funcionario);
        
        funcionarioComPrivilegios.mostrarInfo();
    }
}
