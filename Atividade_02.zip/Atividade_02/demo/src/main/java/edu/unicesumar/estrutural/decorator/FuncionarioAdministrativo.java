package edu.unicesumar.estrutural.decorator;

public class FuncionarioAdministrativo extends FuncionarioDecorator {
    public FuncionarioAdministrativo(Funcionario funcionarioDecorado) {
        super(funcionarioDecorado);
    }

    public void mostrarInfo() {
        super.mostrarInfo();
        System.out.println("Tenho privilégios administrativos.");
    }
}