package edu.unicesumar.comportamental.strategy;

public class Main {
    public static void main(String[] args) {
        // Definindo a estratégia de avaliação presencial
        EstrategiaAvaliacao presencial = new EstrategiaPresencial();
        
        // Realizando uma avaliação presencial
        presencial.realizarAvaliacao();

        // Definindo a estratégia de avaliação remota
        EstrategiaAvaliacao remota = new EstrategiaRemota();
        
        // Realizando uma avaliação remota
        remota.realizarAvaliacao();
    }
}
