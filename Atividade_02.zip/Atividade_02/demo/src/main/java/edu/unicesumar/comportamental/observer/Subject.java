package edu.unicesumar.comportamental.observer;

import java.util.ArrayList;
import java.util.List;

// Subject que notificará os observadores sobre mudanças
public interface Subject {
    void registrarObservador(Observador o);
    void removerObservador(Observador o);
    void notificarObservadores(String mensagem);
}
