package edu.unicesumar.comportamental.strategy;

// Interface para definir uma estratégia de avaliação
public interface EstrategiaAvaliacao {
    void realizarAvaliacao();
}
