package edu.unicesumar.estrutural.decorator;

public class FuncionarioBase implements Funcionario {
    @Override
    public void mostrarInfo() {
        System.out.println("Sou um funcionário da Unicesumar.");
    }
}