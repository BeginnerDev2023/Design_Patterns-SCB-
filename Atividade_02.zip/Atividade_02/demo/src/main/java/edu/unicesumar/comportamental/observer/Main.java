package edu.unicesumar.comportamental.observer;

public class Main {
    public static void main(String[] args) {
        DepartamentoUnicesumar departamento = new DepartamentoUnicesumar();
        departamento.registrarObservador(new DepartamentoObservador("RH"));
        departamento.registrarObservador(new DepartamentoObservador("Financeiro"));

        departamento.atualizarPoliticasInternas("Aumento de benefícios para os funcionários.");
    }
}