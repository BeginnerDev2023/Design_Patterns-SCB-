package edu.unicesumar.criacional.factory_method;

public class Administrativo implements Funcionario {
    @Override
    public void mostrarInfo() {
        System.out.println("Sou um funcionário administrativo da Unicesumar.");
    }
}
