package edu.unicesumar.comportamental.observer;

public class DepartamentoObservador implements Observador {
    private String nomeDepartamento;

    public DepartamentoObservador(String nomeDepartamento) {
        this.nomeDepartamento = nomeDepartamento;
    }

    public void atualizar(String mensagem) {
        System.out.println("Departamento " + nomeDepartamento + " recebeu uma atualização: " + mensagem);
    }
}