package edu.unicesumar.comportamental.strategy;

// Implementação concreta de uma estratégia de avaliação remota
public class EstrategiaRemota implements EstrategiaAvaliacao {
    @Override
    public void realizarAvaliacao() {
        System.out.println("Realizando avaliação remota.");
    }
}
