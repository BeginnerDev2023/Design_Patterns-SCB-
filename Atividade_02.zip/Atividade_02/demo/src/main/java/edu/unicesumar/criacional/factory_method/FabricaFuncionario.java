package edu.unicesumar.criacional.factory_method;

public class FabricaFuncionario {
    // Método factory para criar funcionários
    public Funcionario criarFuncionario(String tipo) {
        if (tipo.equalsIgnoreCase("Professor")) {
            return new Professor();
        } else if (tipo.equalsIgnoreCase("Administrativo")) {
            return new Administrativo();
        } else {
            return null;
        }
    }
}
