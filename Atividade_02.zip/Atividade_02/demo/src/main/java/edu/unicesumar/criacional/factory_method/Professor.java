package edu.unicesumar.criacional.factory_method;

public class Professor implements Funcionario {
    @Override
    public void mostrarInfo() {
        System.out.println("Sou um professor da Unicesumar.");
    }
}