package edu.unicesumar.estrutural.decorator;

public interface Funcionario {
    void mostrarInfo();
}