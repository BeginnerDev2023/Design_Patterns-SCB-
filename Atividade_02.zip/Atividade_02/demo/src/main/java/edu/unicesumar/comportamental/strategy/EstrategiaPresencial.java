package edu.unicesumar.comportamental.strategy;

// Implementação concreta de uma estratégia de avaliação presencial
public class EstrategiaPresencial implements EstrategiaAvaliacao {
    @Override
    public void realizarAvaliacao() {
        System.out.println("Realizando avaliação presencial.");
    }
}