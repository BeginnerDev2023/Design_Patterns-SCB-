package edu.unicesumar.comportamental.observer;

public interface Observador {
    void atualizar(String mensagem);
}
