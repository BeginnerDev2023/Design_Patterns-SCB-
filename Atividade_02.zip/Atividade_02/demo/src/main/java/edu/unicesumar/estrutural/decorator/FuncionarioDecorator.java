package edu.unicesumar.estrutural.decorator;

public abstract class FuncionarioDecorator implements Funcionario {
    protected Funcionario funcionarioDecorado;

    public FuncionarioDecorator(Funcionario funcionarioDecorado) {
        this.funcionarioDecorado = funcionarioDecorado;
    }

    public void mostrarInfo() {
        funcionarioDecorado.mostrarInfo();
    }
}
