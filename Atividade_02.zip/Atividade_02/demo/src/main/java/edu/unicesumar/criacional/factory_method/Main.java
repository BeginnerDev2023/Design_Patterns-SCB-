package edu.unicesumar.criacional.factory_method;

public class Main {
    public static void main(String[] args) {
        FabricaFuncionario fabrica = new FabricaFuncionario();

        Funcionario prof = fabrica.criarFuncionario("Professor");
        Funcionario adm = fabrica.criarFuncionario("Administrativo");

        prof.mostrarInfo();
        adm.mostrarInfo();
    }
}